import pandas as pd
import matplotlib.pyplot as plt

df = pd.read_csv('restaurant_locations.csv')

# Group by city for stats
grouped = df.groupby('city').agg({
    'rating': 'mean',
    'price_range': 'mean',
    'restaurant_id': 'count'
}).rename(columns={'restaurant_id': 'restaurant_count'})

print("Statistics by city:")
print(grouped)

# Plot locations
plt.figure(figsize=(8, 6))
plt.scatter(df['longitude'], df['latitude'], c='blue', label='Restaurants')
for i, row in df.iterrows():
    plt.text(row['longitude'], row['latitude'], row['name'], fontsize=8)
plt.xlabel("Longitude")
plt.ylabel("Latitude")
plt.title("Restaurant Locations")
plt.legend()
plt.grid(True)
plt.tight_layout()
plt.savefig("location_map.png")
plt.show()
